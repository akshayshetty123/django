import datetime
TIMESLOT_START_TIME = datetime.time(14)
TIMESLOT_END_TIME_DURATION = datetime.timedelta(hours=6.5)
