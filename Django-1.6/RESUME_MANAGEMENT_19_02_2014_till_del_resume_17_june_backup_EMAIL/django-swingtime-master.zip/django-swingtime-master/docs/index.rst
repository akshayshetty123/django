.. _index:

Swingtime documentation contents
================================

Table of Contents
-----------------

.. toctree::
   :maxdepth: 3

   intro
   installation
   models
   views
   forms
   utils
   swingtime_settings
   changes


Index
-----

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

