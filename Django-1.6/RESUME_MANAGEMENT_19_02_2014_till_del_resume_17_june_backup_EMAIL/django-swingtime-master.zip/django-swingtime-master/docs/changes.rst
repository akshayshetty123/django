.. _changes:

Changes in Swingtime
====================

Release 0.2.2 (March 16, 2013)
------------------------------

* Registered in PyPI
* Installs with `pip`

Release 0.2 (Decemeber 18, 2008)
--------------------------------

* First public release.