
$.fullCalendar.lang("tl", {
	defaultButtonText: {
		month: "Buwan",
		week: "Linggo",
		day: "Araw",
		list: "Pakay"
	},
	allDayText: "Lahat ng araw"
});
