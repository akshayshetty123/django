
$.fullCalendar.lang("vi", {
	defaultButtonText: {
		month: "Tháng",
		week: "Tuần",
		day: "Ngày",
		list: "Lịch biểu"
	},
	allDayText: "Cả ngày"
});
