
$.fullCalendar.lang("lt", {
	defaultButtonText: {
		month: "Mėnuo",
		week: "Savaitė",
		day: "Diena",
		list: "Darbotvarkė"
	},
	allDayText: "Visą dieną"
});
