
$.fullCalendar.lang("ar", {
	defaultButtonText: {
		month: "شهر",
		week: "أسبوع",
		day: "يوم",
		list: "أجندة"
	},
	allDayText: "اليوم كله"
});
