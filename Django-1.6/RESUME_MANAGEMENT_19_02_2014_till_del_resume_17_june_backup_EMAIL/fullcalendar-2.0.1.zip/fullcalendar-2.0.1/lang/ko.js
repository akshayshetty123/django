
$.fullCalendar.lang("ko", {
	defaultButtonText: {
		month: "월",
		week: "주",
		day: "일",
		list: "일정목록"
	},
	allDayText: "종일"
});
