
$.fullCalendar.lang("en-gb", {
	columnFormat: {
		week: 'ddd D/M'
	}
});
