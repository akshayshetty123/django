
$.fullCalendar.lang("id", {
	defaultButtonText: {
		month: "Bulan",
		week: "Minggu",
		day: "Hari",
		list: "Agenda"
	},
	allDayText: "Sehari penuh"
});
