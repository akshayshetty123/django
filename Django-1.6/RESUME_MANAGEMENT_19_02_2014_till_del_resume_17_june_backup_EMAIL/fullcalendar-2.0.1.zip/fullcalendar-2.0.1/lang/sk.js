
$.fullCalendar.lang("sk", {
	defaultButtonText: {
		month: "Mesiac",
		week: "Týždeň",
		day: "Deň",
		list: "Rozvrh"
	},
	allDayText: "Celý deň"
});
