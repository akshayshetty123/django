
$.fullCalendar.lang("ca", {
	defaultButtonText: {
		month: "Mes",
		week: "Setmana",
		day: "Dia",
		list: "Agenda"
	},
	allDayText: "Tot el dia"
});
