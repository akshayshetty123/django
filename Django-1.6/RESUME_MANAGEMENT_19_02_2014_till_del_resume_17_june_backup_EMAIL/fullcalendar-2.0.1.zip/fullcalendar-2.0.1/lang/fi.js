
$.fullCalendar.lang("fi", {
	defaultButtonText: {
		month: "Kuukausi",
		week: "Viikko",
		day: "Päivä",
		list: "Tapahtumat"
	},
	allDayText: "Koko päivä"
});
