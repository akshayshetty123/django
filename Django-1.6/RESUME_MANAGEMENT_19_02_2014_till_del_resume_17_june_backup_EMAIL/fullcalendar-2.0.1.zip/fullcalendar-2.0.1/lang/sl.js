
$.fullCalendar.lang("sl", {
	defaultButtonText: {
		month: "Mesec",
		week: "Teden",
		day: "Dan",
		list: "Dnevni red"
	},
	allDayText: "Ves dan"
});
