
$.fullCalendar.lang("es", {
	defaultButtonText: {
		month: "Mes",
		week: "Semana",
		day: "Día",
		list: "Agenda"
	},
	allDayText: "Todo el día"
});
