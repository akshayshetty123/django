
$.fullCalendar.lang("nl", {
	defaultButtonText: {
		month: "Maand",
		week: "Week",
		day: "Dag",
		list: "Agenda"
	},
	allDayText: "Hele dag"
});
