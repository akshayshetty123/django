
$.fullCalendar.lang("th", {
	defaultButtonText: {
		month: "เดือน",
		week: "สัปดาห์",
		day: "วัน",
		list: "แผนงาน"
	},
	allDayText: "ตลอดวัน"
});
